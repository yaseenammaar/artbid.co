// var instance = require('./firebase.js')

var db =new dbClass();
alert('test')
// var database = firebase.database();
// var db = new DataBase();
db.get
