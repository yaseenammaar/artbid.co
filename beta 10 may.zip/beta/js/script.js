var database = firebase.database();

    var imageid = localStorage.getItem("imageid");
    var furl = localStorage.getItem("furl");

    var imgurls = [];
    var currentprice = 0;
    var lastbidder;
    var lastamount;
    var doneonce = 0;

    function getitems()
    {
        var dbref = database.ref('items').child(imageid);
        dbref.on("value", function(child){
          $('#title').html(child.val().title);
          $('#price').html("<b>₹ " + child.val().b_price + "</b>");
          $('#description').html(child.val().caption);
          currentprice = child.val().b_price;
          if(doneonce==1){
              location.reload();
          }
          doneonce = 1;


          child.forEach(function(snapshot){

          })
          imgurls = child.val().imgurl;


          localStorage.setItem("imgurls",imgurls);

          database.ref('user').child(child.val().byUser).on("value", function(snap){
                $('#byuser').html("By " + snap.val().username);
            })
          });
        var count = 0;

        var dbref = database.ref('items').child(imageid).child('bidders');
          dbref.on('value', function(snapshot) {
            count=0;
            snapshot.forEach(function(child){
              lastbidder = child.val().userid;
              lastamount = child.val().amount;
              currentprice = lastamount;
              console.log('Bidders : ' + lastbidder)
              console.log('Amount : ' + lastamount)
              console.log('Count : ' + count)
              count++;
              if(snapshot.numChildren()==count)
              {
                database.ref('user').child(lastbidder).on("value", function(snap){
                console.log('OL : Bidders : ' + lastbidder);
                console.log('OL : Amount : ' + lastamount); 
                currentprice = lastamount;
                console.log('OL : Current bid : ' + currentprice); 
                var nextminbid =  parseFloat(currentprice) + parseFloat(currentprice *.01);
                nextminbid -= 1;
                $('#nextbidtext').html("<b>Next min bid ₹ " + nextminbid + "</b>");
                console.log('OL : username : ' + snap.val().username)

                $('#price').html("<b>₹ " + lastamount + " by "+snap.val().username+"</b>");
                })
              }

            })
            
            
              // take the last item with the lowest key in the snapshot
          });
        // dbref.on("value", function(child){
        //   child.forEach(function(snapshot){
        //     bidders.push(snapshot.val());
        //   })
        // });
        
    }

    getitems();



  function navtopreview(){
    if(screen.width>800)
    {
      goto('preview.html');
    }else{
      goto('mpreview.html');
    }
  }

  function bid(){
    var bidamount = $('#bidamount').val();
    var nextbidamount = parseInt(currentprice) + parseFloat(currentprice*.01);

    firebase.auth().onAuthStateChanged((user) => {
      if (user) {
        if(user.uid==lastbidder)
        {
          Swal.fire(
              'You are dominating',
              'You cannot bid again',
              'info',
            )
        }else{
          if(bidamount<nextbidamount)
            {
              Swal.fire(
                'Too Less',
                'Next bid must be more than ' + (nextbidamount-1),
                'error',
              )
            }else{
              let timerInterval
              Swal.fire({
                title: 'Processing..',
                timer: 80,
                timerProgressBar: true,
                onBeforeOpen: () => {
                  Swal.showLoading()
                  timerInterval = setInterval(() => {
                    
                  }, 100)
                },
                onClose: () => {
                  clearInterval(timerInterval)
                }

              }).then((result) => {
                /* Read more about handling dismissals below */
                Swal.fire(
                'Woo Hoo.. Bidded',
                'You are now dominating',
                'success',
              )
              })
              biddata(user.uid);

            }
        }
      } else {
        Swal.fire(
            'You must login before placing bid',
            '',
            'error',
          )
      }
    });  
    
  }

  function biddata(uid){

    var newKey = firebase.database().ref('/').push().key;
    var currentdate = new Date(); 
    var dbrefer = firebase.database();
    var keys = [];
    dbrefer.ref('user/'+uid+'/biddeditems').on("value", function(child){        
      child.forEach(function(snapshot){
        keys.push(snapshot.val().newkey);

      });
    var available = (keys.indexOf(imageid) > -1);
    if(available==-1)
    {
      dbrefer.ref('user/'+uid+'/biddeditems/' + newKey ).set({
        "newkey":imageid
      })
    }
    });

    
    dbrefer.ref('items/'+imageid+'/bidders/' + newKey).set({
      "newkey":imageid,
      "userid":uid,
      "amount":$('#bidamount').val(),
      "datetime":Date()
    })
    location.reload();
  }


  function checkauth(){

    //check authentication then

    // window.location.href = 'login.html';
    window.location.href = 'profile.html';

  }


  function showupcomingdialog(){
      Swal.fire(
        'Upcoming!!!',
        'Told You',
        'info',
      )
  }
  function goto(link){
    var delayInMilliseconds = 500; //1 second


    setTimeout(function() {
      window.location.href = link;
    }, delayInMilliseconds);

    
  }
  


  function showResult(str) {
    if (str.length==0) {
      document.getElementById("livesearch").innerHTML="";
      document.getElementById("livesearch").style.border="0px";
      return;
    }
    document.getElementById("livesearch").innerHTML=str;
    document.getElementById("livesearch").style.border="1px solid #A5ACB2";
  }


  $(document).ready(function() {
  var ripple_wrap = $('.ripple-wrap'),
      rippler = $('.ripple'),
      finish = false,
      monitor = function(el) {
        var computed = window.getComputedStyle(el, null),
            borderwidth = parseFloat(computed.getPropertyValue('border-left-width'));
        if (!finish && borderwidth >= 1500) {
          el.style.WebkitAnimationPlayState = "paused";
          el.style.animationPlayState = "paused";
          swapContent();
        }
        if (finish) {
          el.style.WebkitAnimationPlayState = "running";
          el.style.animationPlayState = "running";
          return;
        } else {
          window.requestAnimationFrame(function() {monitor(el)});
        }
      };
  
  storedcontent = $('#content-2').html();
  $('#content-2').remove();
  
  rippler.bind("webkitAnimationEnd oAnimationEnd msAnimationEnd mozAnimationEnd animationend", function(e){
    ripple_wrap.removeClass('goripple');
  });

  $('body').on('click', 'li', function(e) {
    rippler.css('left', e.clientX + 'px');
    rippler.css('top', e.clientY + 'px');
    e.preventDefault();
    finish = false;
    ripple_wrap.addClass('goripple');
    window.requestAnimationFrame(function() {monitor(rippler[0])});
    
    
  });

  
  
 
  function swapContent() {
      var newcontent = $('#content-area').html();
      $('#content-area').html(storedcontent);
      storedcontent = newcontent;
      // do some Ajax, put it in the DOM and then set this to true
      setTimeout(function() {
        finish = true;
      },10);
  }
  
});