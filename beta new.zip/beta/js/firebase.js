var firebaseConfig = {
        apiKey: "AIzaSyBB8EVN1e95UFiz7_CLxSCygWPwWaMDang",
        authDomain: "artbid-d3199.firebaseapp.com",
        databaseURL: "https://artbid-d3199.firebaseio.com",
        projectId: "artbid-d3199",
        storageBucket: "artbid-d3199.appspot.com",
        messagingSenderId: "255159898856",
        appId: "1:255159898856:web:3f38ec796ee4587427af5d",
        measurementId: "G-NLYVBLNPLW"
      };
      // Initialize Firebase
      // firebase.analytics();
    
      firebase.initializeApp(firebaseConfig);
